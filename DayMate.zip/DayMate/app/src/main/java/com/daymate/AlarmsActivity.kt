package com.daymate
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.*

class AlarmsActivity : Activity() {
    private val call get() = intent.getBooleanExtra("call", false)
    override fun onResume() { super.onResume(); render() }
    override fun onCreate(b: Bundle?) { super.onCreate(b) }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        root.addView(TextView(this).apply { text = if (call) "Routine calls" else "Sleep & wake-up alarms"; textSize = 26f })
        Store.all(this).filter { it.call == call }.forEach { a ->
            val row = LinearLayout(this).apply { setPadding(0, 24, 0, 24) }
            row.addView(TextView(this).apply {
                text = "%02d:%02d  %s\n%s%s".format(a.hour, a.minute, a.label, if (a.daily) "Every day" else "Once", if (call) " • ${a.name}" else "")
                textSize = 18f
                setOnClickListener { startActivity(Intent(this@AlarmsActivity, EditActivity::class.java).putExtra("id", a.id).putExtra("call", call)) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Switch(this).apply {
                isChecked = a.on
                setOnCheckedChangeListener { _, on -> a.on = on; Store.update(context, a); if (on) Scheduler.set(context, a) else Scheduler.cancel(context, a.id) }
            })
            root.addView(row)
        }
        root.addView(Button(this).apply {
            text = "+ New"
            setOnClickListener { startActivity(Intent(this@AlarmsActivity, EditActivity::class.java).putExtra("call", call)) }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
