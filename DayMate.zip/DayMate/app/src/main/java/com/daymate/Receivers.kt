package com.daymate
import android.content.*
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = Store.get(c, i.getIntExtra("id", -1)) ?: return
        val snooze = i.getBooleanExtra("snz", false)
        if (!a.on && !snooze) return
        if (!snooze) {
            if (a.daily) Scheduler.set(c, a) else { a.on = false; Store.update(c, a) }
        }
        ContextCompat.startForegroundService(c, Intent(c, RingService::class.java).putExtra("id", a.id))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.all(c).filter { it.on }.forEach { Scheduler.set(c, it) }
    }
}
