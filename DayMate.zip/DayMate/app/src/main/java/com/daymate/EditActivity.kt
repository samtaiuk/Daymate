package com.daymate
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import org.json.JSONObject

class EditActivity : ComponentActivity() {
    private lateinit var a: Alarm
    private var w: Alarm? = null
    private lateinit var tb: Button; private lateinit var wb: Button; private lateinit var rb: Button
    private lateinit var cb: Button; private lateinit var sb: Button
    private var end = ""; private var status = 0
    private val mode by lazy { intent.getStringExtra("mode") ?: "pair" }
    private val names = listOf("⏳ Pending", "✅ Completed", "⏭️ Postponed")
    private fun hm(h: Int, m: Int) = "%02d:%02d".format(h, m)

    private val pickTone = registerForActivityResult(StartActivityForResult()) { r ->
        @Suppress("DEPRECATION")
        r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)?.let { a.tone = it.toString(); w?.tone = a.tone; upd() }
    }
    private val pickContact = registerForActivityResult(StartActivityForResult()) { r ->
        r.data?.data?.let { u ->
            contentResolver.query(u, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { c ->
                if (c.moveToFirst()) { a.name = c.getString(0); a.number = c.getString(1); upd() }
            }
        }
    }
    private fun pickTime(h: Int, m: Int, f: (Int, Int) -> Unit) = TimePickerDialog(this, { _, x, y -> f(x, y); upd() }, h, m, false).show()

    private fun upd() {
        tb.text = (if (mode == "pair") "😴 Bedtime " else "⏰ Start ") + hm(a.hour, a.minute)
        wb.text = if (mode == "task") "End time: " + end.ifEmpty { "tap to set" } else "🌅 Wake-up " + hm(w?.hour ?: 0, w?.minute ?: 0)
        sb.text = names[status]
        rb.text = "🔔 Tone: " + (if (a.tone.isEmpty()) "Default alarm" else RingtoneManager.getRingtone(this, Uri.parse(a.tone))?.getTitle(this) ?: "Custom")
        cb.text = "👤 Contact: " + a.name.ifEmpty { "choose" }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val me = this
        val seed = (System.currentTimeMillis() / 1000).toInt()
        a = Store.get(this, intent.getIntExtra("id", -1)) ?: when (mode) {
            "pair" -> Alarm(seed and 0x3FFFFE, 22, 0, "Bedtime", true, false, "", "", "", 1)
            "call" -> Alarm(seed and 0x3FFFFF, 7, 0, "", true, true, "", "", "", 0)
            else -> Alarm(TASK + (seed and 0x3FFFFF), 7, 0, "", false, false, "", "", "", 0)
        }
        if (mode == "pair") w = Store.get(this, a.id + 1) ?: Alarm(a.id + 1, 6, 30, "Wake up", true, false, "", "", a.tone, 2)
        val ext = ex(a.id); status = ext.optInt("s"); end = ext.optString("e")
        tb = Button(this).apply { setOnClickListener { pickTime(a.hour, a.minute) { h, m -> a.hour = h; a.minute = m } } }
        wb = Button(this).apply { setOnClickListener {
            if (mode == "task") pickTime(a.hour, a.minute) { h, m -> end = hm(h, m) }
            else w?.let { x -> pickTime(x.hour, x.minute) { h, m -> x.hour = h; x.minute = m } }
        } }
        sb = Button(this).apply { setOnClickListener { status = (status + 1) % 3; upd() } }
        rb = Button(this).apply { setOnClickListener {
            pickTone.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true))
        } }
        cb = Button(this).apply { setOnClickListener { pickContact.launch(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI)) } }
        val et = EditText(this).apply { hint = if (mode == "task") "Activity" else "Label (e.g. Call mum)"; setText(a.label) }
        val rem = EditText(this).apply { hint = "Remark"; setText(ext.optString("r")) }
        val rg = RadioGroup(this).apply {
            addView(RadioButton(context).apply { text = "Once"; id = 1 })
            addView(RadioButton(context).apply { text = if (mode == "task") "Repeat every day" else "Every day"; id = 2 })
            check(if (a.daily) 2 else 1)
        }
        val save = Button(this).apply { text = "Save"; setOnClickListener {
            if (mode == "call" && a.number.isEmpty()) { Toast.makeText(me, "Choose a contact", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            a.label = if (mode == "pair") "Bedtime" else et.text.toString()
            a.daily = rg.checkedRadioButtonId == 2; a.on = true
            w?.let { it.daily = a.daily; it.tone = a.tone; it.on = true }
            if (mode == "task" && !a.daily && status != 0) a.on = false
            val l = Store.all(me)
            listOfNotNull(a, w).forEach { x ->
                val i = l.indexOfFirst { it.id == x.id }; if (i >= 0) l[i] = x else l.add(x)
                if (x.on) Scheduler.set(me, x) else Scheduler.cancel(me, x.id)
            }
            Store.save(me, l)
            if (mode == "task") me.setEx(a.id, JSONObject().put("s", status).put("e", end).put("r", rem.text.toString()))
            if (mode == "pair" && !me.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted)
                try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (e: Exception) {}
            Toast.makeText(me, "Saved", Toast.LENGTH_SHORT).show(); finish()
        } }
        val del = Button(this).apply { text = "Delete"; setOnClickListener {
            AlertDialog.Builder(me).setMessage("Delete?").setNegativeButton("No", null).setPositiveButton("Yes") { _, _ ->
                val ids = listOfNotNull(a.id, w?.id); ids.forEach { Scheduler.cancel(me, it) }
                Store.save(me, Store.all(me).filter { it.id !in ids }); finish()
            }.show()
        } }
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        v.addView(tb)
        if (mode == "pair") v.addView(wb) else v.addView(et)
        if (mode == "task") { v.addView(wb); v.addView(sb); v.addView(rem) }
        v.addView(rg); v.addView(rb)
        if (mode == "call") v.addView(cb)
        v.addView(save); v.addView(del)
        upd(); setContentView(ScrollView(this).apply { addView(v) })
    }
}
