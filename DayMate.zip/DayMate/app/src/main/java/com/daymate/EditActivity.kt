package com.daymate
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult

class EditActivity : ComponentActivity() {
    private lateinit var a: Alarm
    private lateinit var tb: Button; private lateinit var cb: Button; private lateinit var rb: Button; private lateinit var db: Button
    private val dndText = listOf("Do Not Disturb: leave as is", "Do Not Disturb: turn ON (alarms only)", "Do Not Disturb: turn OFF")

    private val pickTone = registerForActivityResult(StartActivityForResult()) { r ->
        @Suppress("DEPRECATION")
        r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)?.let { a.tone = it.toString(); upd() }
    }
    private val pickContact = registerForActivityResult(StartActivityForResult()) { r ->
        r.data?.data?.let { u ->
            contentResolver.query(u, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { c ->
                if (c.moveToFirst()) { a.name = c.getString(0); a.number = c.getString(1); upd() }
            }
        }
    }

    private fun upd() {
        tb.text = "⏰ %02d:%02d".format(a.hour, a.minute)
        rb.text = "🔔 Tone: " + (if (a.tone.isEmpty()) "Default alarm" else RingtoneManager.getRingtone(this, Uri.parse(a.tone))?.getTitle(this) ?: "Custom")
        cb.text = "👤 Contact: " + a.name.ifEmpty { "choose" }
        db.text = dndText[a.dnd]
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val call = intent.getBooleanExtra("call", false)
        a = Store.get(this, intent.getIntExtra("id", -1))
            ?: Alarm((System.currentTimeMillis() / 1000).toInt() and 0x7FFFFF, 7, 0, "", true, call, "", "", "", 0)
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        tb = Button(this).apply { setOnClickListener { TimePickerDialog(context, { _, h, m -> a.hour = h; a.minute = m; upd() }, a.hour, a.minute, false).show() } }
        val et = EditText(this).apply { hint = if (call) "Label (e.g. Call mum)" else "Label (e.g. Wake up / Sleep)"; setText(a.label) }
        val rg = RadioGroup(this).apply {
            addView(RadioButton(context).apply { text = "Once"; id = 1 })
            addView(RadioButton(context).apply { text = "Every day"; id = 2 })
            check(if (a.daily) 2 else 1)
        }
        rb = Button(this).apply { setOnClickListener {
            pickTone.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true))
        } }
        cb = Button(this).apply { setOnClickListener { pickContact.launch(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI)) } }
        db = Button(this).apply { setOnClickListener { a.dnd = (a.dnd + 1) % 3; upd() } }
        val save = Button(this).apply { text = "Save"; setOnClickListener {
            if (a.call && a.number.isEmpty()) { toast("Choose a contact"); return@setOnClickListener }
            a.label = et.text.toString(); a.daily = rg.checkedRadioButtonId == 2; a.on = true
            val l = Store.all(context)
            if (l.any { it.id == a.id }) Store.update(context, a) else { l.add(a); Store.save(context, l) }
            Scheduler.set(context, a)
            val nm = getSystemService(NotificationManager::class.java)
            if (a.dnd != 0 && !nm.isNotificationPolicyAccessGranted) startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            toast("Alarm set"); finish()
        } }
        val del = Button(this).apply { text = "Delete"; setOnClickListener {
            AlertDialog.Builder(context).setMessage("Delete this alarm?").setNegativeButton("No", null).setPositiveButton("Yes") { _, _ ->
                Scheduler.cancel(context, a.id); Store.save(context, Store.all(context).filter { it.id != a.id }); finish()
            }.show()
        } }
        listOf(tb, et, rg, rb).forEach { v.addView(it) }
        if (a.call) v.addView(cb)
        listOf(db, save, del).forEach { v.addView(it) }
        upd(); setContentView(ScrollView(this).apply { addView(v) })
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
