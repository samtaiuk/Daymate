package com.daymate
import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private class T(val e: String, val l: String, val f: () -> Unit)
    private lateinit var root: FrameLayout
    private val green = Color.parseColor("#1B6B2F")
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    private val photo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            sp().edit().putString("bgu", u.toString()).apply(); applyBg()
        }
    }
    private fun sp() = getSharedPreferences("dm", 0)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun soon() = Toast.makeText(this, "Coming soon", Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        perms.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR, Manifest.permission.POST_NOTIFICATIONS))
        root = FrameLayout(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(20)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), dp(12)) }
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(TextView(this).apply { text = "DayMate"; textSize = 32f; setTypeface(null, Typeface.BOLD); setTextColor(green) })
        t.addView(TextView(this).apply { text = "Your day, planned with purpose." })
        head.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(Button(this).apply { text = "☰"; setOnClickListener { menu() } })
        col.addView(head)

        val tiles = listOf(
            T("📅", "Calendar") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time/" + System.currentTimeMillis()))) },
            T("⏰", "Sleep & wake-up alarm") { startActivity(Intent(this, AlarmsActivity::class.java)) },
            T("☑️", "Daily itinerary") { soon() },
            T("💧", "Drink water") { soon() },
            T("➕", "Event") { startActivity(Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)) },
            T("☎️", "Routine calls") { startActivity(Intent(this, AlarmsActivity::class.java).putExtra("call", true)) },
            T("🎮", "Games") { soon() },
            T("📊", "Productivity analysis") { soon() },
            T("🎵", "Online music") { soon() },
            T("⏱️", "Game limit") { soon() },
            T("⚙️", "Settings") { menu() })
        tiles.chunked(3).forEach { row ->
            val h = LinearLayout(this)
            row.forEach { tile ->
                h.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(6), dp(6), dp(6))
                    background = GradientDrawable().apply { setColor(Color.argb(235, 255, 255, 255)); cornerRadius = dp(10).toFloat() }
                    elevation = dp(2).toFloat()
                    addView(TextView(context).apply { text = tile.e; textSize = 32f; gravity = Gravity.CENTER })
                    addView(TextView(context).apply { text = tile.l; textSize = 15f; setTypeface(null, Typeface.BOLD); setTextColor(green); gravity = Gravity.CENTER })
                    setOnClickListener { tile.f() }
                }, LinearLayout.LayoutParams(0, dp(112), 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            }
            repeat(3 - row.size) { h.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            col.addView(h)
        }
        root.addView(ScrollView(this).apply { addView(col) })
        setContentView(root); applyBg()
    }

    private fun applyBg() {
        val u = sp().getString("bgu", null)
        try {
            if (u != null) contentResolver.openInputStream(Uri.parse(u))?.use {
                root.background = BitmapDrawable(resources, BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 }))
            } else root.setBackgroundColor(sp().getInt("bgc", Color.parseColor("#F4F8F4")))
        } catch (e: Exception) { root.setBackgroundColor(Color.parseColor("#F4F8F4")) }
    }
    private fun setC(c: String) { sp().edit().remove("bgu").putInt("bgc", Color.parseColor(c)).apply(); applyBg() }

    private fun menu() {
        val o = arrayOf("Background: choose photo", "Background: light green", "Background: dark", "Background: sunset", "Background: ocean",
            "Background: reset", "Allow Do Not Disturb control", "Allow full-screen alarms", "Ignore battery optimisation")
        AlertDialog.Builder(this).setItems(o) { _, i ->
            when (i) {
                0 -> photo.launch(arrayOf("image/*"))
                1 -> setC("#C8E6C9"); 2 -> setC("#263238"); 3 -> setC("#FFCC80"); 4 -> setC("#B3E5FC")
                5 -> setC("#F4F8F4")
                6 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                7 -> if (Build.VERSION.SDK_INT >= 34) startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
                8 -> startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }.show()
    }
}
