package com.daymate.app

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.Settings

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val prefs = c.getSharedPreferences("daymate", 0)
        val savedTone = prefs.getString("tone_uri", "")
        val soundUri = if (savedTone.isNullOrBlank()) Settings.System.DEFAULT_NOTIFICATION_URI else Uri.parse(savedTone)
        // Use a channel ID tied to the chosen tone: Android locks sound settings per channel.
        val channelId = "daymate_" + (savedTone ?: "default").hashCode().toString()
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(channelId) == null) {
                val channel = NotificationChannel(channelId, "DayMate reminders", NotificationManager.IMPORTANCE_HIGH)
                channel.description = "Alarms and reminders from DayMate"
                channel.setSound(soundUri, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                nm.createNotificationChannel(channel)
            }
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, channelId) else Notification.Builder(c)
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(i.getStringExtra("title") ?: "DayMate reminder")
            .setContentText(i.getStringExtra("message") ?: "It's time.")
            .setAutoCancel(true)
        if (Build.VERSION.SDK_INT < 26) b.setSound(soundUri)
        nm.notify(i.getIntExtra("id", 1001), b.build())
        if (i.getBooleanExtra("wake", false) && Build.VERSION.SDK_INT >= 23) {
            if (prefs.getBoolean("restore_dnd", true) && nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
        }
    }
}

object ReminderScheduler {
    fun schedule(c: Context, id: Int, at: Long, title: String, msg: String, wake: Boolean = false) {
        val i = Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("title", title).putExtra("message", msg).putExtra("wake", wake)
        val p = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val a = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !a.canScheduleExactAlarms()) a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        else if (Build.VERSION.SDK_INT >= 23) a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        else a.setExact(AlarmManager.RTC_WAKEUP, at, p)
    }
}
