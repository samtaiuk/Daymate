package com.daymate.app
import android.app.*
import android.content.*
import android.os.Build
import android.media.RingtoneManager
class ReminderReceiver: BroadcastReceiver(){ override fun onReceive(c:Context,i:Intent){
 val nm=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
 if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel("daymate","DayMate reminders",NotificationManager.IMPORTANCE_HIGH))
 val b=if(Build.VERSION.SDK_INT>=26) Notification.Builder(c,"daymate") else Notification.Builder(c)
 b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(i.getStringExtra("title")?:"DayMate reminder").setContentText(i.getStringExtra("message")?:"It's time.").setAutoCancel(true).setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
 nm.notify(i.getIntExtra("id",1001),b.build())
 if(i.getBooleanExtra("wake",false)&&Build.VERSION.SDK_INT>=23){val m=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;if(c.getSharedPreferences("daymate",0).getBoolean("restore_dnd",true)&&m.isNotificationPolicyAccessGranted)m.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)}
}}
object ReminderScheduler { fun schedule(c:Context,id:Int,at:Long,title:String,msg:String,wake:Boolean=false){val i=Intent(c,ReminderReceiver::class.java).putExtra("id",id).putExtra("title",title).putExtra("message",msg).putExtra("wake",wake);val p=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val a=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager;if(Build.VERSION.SDK_INT>=31&&!a.canScheduleExactAlarms())a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p) else if(Build.VERSION.SDK_INT>=23)a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p) else a.setExact(AlarmManager.RTC_WAKEUP,at,p)} }
