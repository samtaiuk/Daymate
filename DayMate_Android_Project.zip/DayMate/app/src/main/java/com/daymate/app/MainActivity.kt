package com.daymate.app

import android.app.*
import android.content.*
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.Settings
import android.media.RingtoneManager
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val green = 0xFF238636.toInt()
    private lateinit var p: android.content.SharedPreferences
    private lateinit var list: LinearLayout
    private var pendingTonePick = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("daymate", 0)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != 0) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        render()
    }

    @Deprecated("Deprecated by Android but supported for the ringtone picker on older versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 21 && resultCode == RESULT_OK && data != null) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
                else @Suppress("DEPRECATION") data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            p.edit().putString("tone_uri", uri?.toString() ?: "").apply()
            toast(if (uri == null) "Default phone notification tone selected" else "Phone tone saved for new reminders")
        }
        pendingTonePick = false
    }

    private fun render() {
        val s = ScrollView(this)
        list = LinearLayout(this).apply { orientation = 1; setPadding(20, 18, 20, 24); setBackgroundColor(0xFFF4FAF4.toInt()) }
        s.addView(list); setContentView(s)
        list.addView(TextView(this).apply { text = "DayMate"; textSize = 30f; setTextColor(green); setTypeface(null, 1) })
        list.addView(TextView(this).apply { text = "Your day, planned with purpose."; setPadding(0, 0, 0, 15) })

        card("Phone tone", "Choose a sound already on your phone for new DayMate reminders") {
            if (!pendingTonePick) {
                pendingTonePick = true
                val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_ALARM)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose DayMate reminder tone")
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                    val saved = p.getString("tone_uri", "")
                    if (!saved.isNullOrBlank()) putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(saved))
                }
                try { startActivityForResult(i, 21) } catch (e: Exception) { pendingTonePick = false; toast("Your phone does not provide a ringtone picker") }
            }
        }

        card("Phone calendar", "View upcoming events from your Android calendar") { loadCalendar() }
        card("Add calendar event", "Open your phone calendar to create an event") {
            try { startActivity(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE, "DayMate event")) }
            catch (e: Exception) { toast("No calendar app is available") }
        }
        card("Wake-up alarm", "Daily wake-up reminder") {
            val t = field("Time HH:MM"); t.setText(p.getString("wake", "06:30"))
            dialog("Wake-up alarm", t) { parse(t.text.toString())?.let { p.edit().putString("wake", t.text.toString()).apply(); daily(10, it.first, it.second, "Good morning", "Time to wake up.", true) } ?: toast("Use HH:MM") }
        }
        card("Daily itinerary", "Time, activity, remarks and end time") {
            val box = LinearLayout(this).apply { orientation = 1 }; val a = field("Start time"); val b = field("Activity"); val c = field("Remarks"); val d = field("End time")
            listOf(a,b,c,d).forEach { box.addView(it) }
            dialog("Add activity", box) { if (b.text.isNotBlank()) { val items = p.getString("items", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList(); items.add("${a.text}|${b.text}|${c.text}|${d.text}"); p.edit().putString("items", items.joinToString("\n")).apply(); render() } else toast("Enter activity") }
        }
        val items = p.getString("items", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
        if (items.isNotEmpty()) { list.addView(label("Today's itinerary")); items.forEachIndexed { idx, item -> list.addView(TextView(this).apply { text = item.replace("|", "  •  "); setPadding(10,12,10,12); setBackgroundColor(-1); setOnLongClickListener { items.removeAt(idx); p.edit().putString("items", items.joinToString("\n")).apply(); render(); true } }) } }
        card("Drink water", "Start periodic water notifications") { val t = field("Interval minutes, 15–240"); t.setText("60"); dialog("Water reminder", t) { val n = t.text.toString().toIntOrNull(); if (n != null && n in 15..240) { water(n); toast("Water reminder started") } else toast("Choose 15–240 minutes") } }
        card("Event reminder", "Schedule one event by date and time") {
            val box = LinearLayout(this).apply { orientation = 1 }; val a = field("Event name"); val b = field("Date YYYY-MM-DD"); val c = field("Time HH:MM"); listOf(a,b,c).forEach { box.addView(it) }
            dialog("Event", box) { try { val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { isLenient = false }.parse("${b.text} ${c.text}")!!; if (date.time <= System.currentTimeMillis()) throw Exception(); ReminderScheduler.schedule(this, (System.currentTimeMillis() % 99999).toInt(), date.time, a.text.toString().ifBlank { "Event" }, "Your event is due."); toast("Event scheduled") } catch (e: Exception) { toast("Check date and time") } }
        }
        card("Routine calls", "Daily reminder to call someone") {
            val box = LinearLayout(this).apply { orientation = 1 }; val a = field("Person to call"); val b = field("Time HH:MM"); box.addView(a); box.addView(b)
            dialog("Routine call", box) { parse(b.text.toString())?.let { daily((System.currentTimeMillis() % 99999).toInt(), it.first, it.second, "Routine call", "Remember to call ${a.text}") } ?: toast("Use HH:MM") }
        }
        card("Gaming limit", "Notify after one hour; cannot force-stop games") { Button(this).apply { text = "Start 1-hour timer"; setOnClickListener { ReminderScheduler.schedule(this@MainActivity, 301, System.currentTimeMillis() + 3600000, "Gaming break", "One hour is up. Take a break."); toast("Timer started") } } }
        card("Bedtime", "Schedule sleep reminder") { val t = field("Time HH:MM"); t.setText("22:00"); dialog("Bedtime", t) { parse(t.text.toString())?.let { daily(40, it.first, it.second, "Time to sleep", "Would you like to enable Do Not Disturb?"); try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (e: Exception) { } } ?: toast("Use HH:MM") } }
        card("DND permission", "Allow DayMate to restore normal notifications at wake-up") { p.edit().putBoolean("restore_dnd", true).apply(); try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (e: Exception) { } }
        list.addView(TextView(this).apply { text = "Offline by design • Data stored locally. Calendar access is optional. Grant notification, exact-alarm and DND permissions for best results."; textSize = 12f; setPadding(0,20,0,0) })
    }

    private fun loadCalendar() {
        if (checkSelfPermission(android.Manifest.permission.READ_CALENDAR) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.READ_CALENDAR), 22); return
        }
        showCalendarEvents()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 22) { if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) showCalendarEvents() else toast("Calendar permission was not granted") }
    }
    private fun showCalendarEvents() {
        val now = System.currentTimeMillis(); val end = now + 30L * 24 * 60 * 60 * 1000
        val events = mutableListOf<String>()
        val projection = arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART, CalendarContract.Events.ALL_DAY)
        val selection = "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} < ? AND ${CalendarContract.Events.DELETED}=0"
        try {
            val cur: Cursor? = contentResolver.query(CalendarContract.Events.CONTENT_URI, projection, selection, arrayOf(now.toString(), end.toString()), "${CalendarContract.Events.DTSTART} ASC")
            cur?.use { while (it.moveToNext() && events.size < 30) { val title = it.getString(0) ?: "(Untitled event)"; val time = it.getLong(1); events.add(SimpleDateFormat("EEE, dd MMM  HH:mm", Locale.getDefault()).format(Date(time)) + "  •  " + title) } }
        } catch (e: Exception) { toast("Could not read calendar events"); return }
        val message = if (events.isEmpty()) "No upcoming calendar events were found in the next 30 days." else events.joinToString("\n\n")
        AlertDialog.Builder(this).setTitle("Upcoming phone calendar events").setMessage(message).setPositiveButton("OK", null).show()
    }
    private fun card(title: String, sub: String, act: () -> Unit) { val v = LinearLayout(this).apply { orientation = 1; setPadding(13,12,13,12); setBackgroundColor(-1) }; v.addView(label(title)); v.addView(TextView(this).apply { text = sub; setTextColor(0xFF5E6F60.toInt()) }); v.addView(Button(this).apply { text = "Set up"; setOnClickListener { act() } }); list.addView(v, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 10 }) }
    private fun label(s: String) = TextView(this).apply { text = s; textSize = 18f; setTextColor(green); setTypeface(null,1); setPadding(0,4,0,7) }
    private fun field(h: String) = EditText(this).apply { hint = h; setSingleLine() }
    private fun dialog(t: String, v: View, save: () -> Unit) { AlertDialog.Builder(this).setTitle(t).setView(v).setPositiveButton("Save") { _, _ -> save() }.setNegativeButton("Cancel", null).show() }
    private fun parse(s: String): Pair<Int,Int>? { val a=s.trim().split(":"); val h=a.getOrNull(0)?.toIntOrNull(); val m=a.getOrNull(1)?.toIntOrNull(); return if(h!=null&&m!=null&&h in 0..23&&m in 0..59) h to m else null }
    private fun daily(id:Int,h:Int,m:Int,title:String,msg:String,wake:Boolean=false) { val c=Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,h); set(Calendar.MINUTE,m); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0); if(timeInMillis<=System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1) }; ReminderScheduler.schedule(this,id,c.timeInMillis,title,msg,wake); toast("Reminder scheduled") }
    private fun water(mins:Int) { ReminderScheduler.schedule(this,200,System.currentTimeMillis()+mins*60000L,"Drink water","Take a moment to drink water.") }
    private fun toast(s:String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
