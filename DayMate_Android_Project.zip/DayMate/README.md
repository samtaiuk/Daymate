# DayMate Android starter project
Native Kotlin Android source project intended for offline use. This is not an APK and has not been compiled or tested on a physical device.

## Build APK
Open this folder in Android Studio on a computer, install Android SDK Platform 35, allow Gradle sync, then choose Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`. Initial dependency download requires internet; installed app runtime is designed not to use network access.

## Limitations
Daily reminders are one-shot alarms, and recurrence/reboot rescheduling needs improvement. Gaming timer notifies only; it cannot reliably force-stop another app. DND restoration needs Notification Policy Access. Exact-alarm and notification permissions are needed; manufacturer battery restrictions may delay alarms.

## Build from a phone using GitHub Actions (no computer required)
1. Sign in to GitHub in your phone browser and create a new repository.
2. Upload the extracted project files to the repository (including `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab and select **Build DayMate APK**. Tap **Run workflow** (or let the first push trigger it).
4. When the workflow finishes successfully, open its run page, find **Artifacts**, and download `DayMate-debug-apk`. Extract it and install `app-debug.apk` on your phone, allowing installs from your browser/files app when Android asks.

The cloud workflow has been added but has **not** been executed from this environment. It may reveal build issues that need fixing; do not treat the APK as available until the workflow succeeds.
