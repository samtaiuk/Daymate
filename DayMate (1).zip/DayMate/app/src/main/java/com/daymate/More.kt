package com.daymate
import android.app.Activity
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.util.Calendar

class ProductivityActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = mutableListOf<View>(tv("📊 Productivity", 26f))
        val tasks = Store.all(this).filter { it.id >= TASK }.sortedBy { it.hour * 60 + it.minute }
        val st = tasks.map { ex(it.id).optInt("s") }
        l.add(tv("Itinerary: ✅ ${st.count { it == 1 }} done · ⏳ ${st.count { it == 0 }} pending · ⏭️ ${st.count { it == 2 }} postponed", 17f))
        tasks.forEach { a ->
            val e = ex(a.id); val en = e.optString("e")
            val d = if (en.length == 5) { var m = en.take(2).toInt() * 60 + en.drop(3).toInt() - (a.hour * 60 + a.minute); if (m < 0) m += 1440; " (${m}m)" } else ""
            l.add(tv("%02d:%02d–%s  %s%s %s".format(a.hour, a.minute, en.ifEmpty { "--" }, a.label, d, e.optString("r"))))
        }
        l.add(tv("🎮 Games today: ${getSharedPreferences("dm", 0).getLong("gplay" + today(), 0) / 60000} min", 17f))
        l.add(tv("📱 Time spent on apps today", 20f))
        if (!hasUsage()) l.add(btn("Allow usage access to record app time") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        else {
            val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
            getSystemService(UsageStatsManager::class.java).queryAndAggregateUsageStats(c.timeInMillis, System.currentTimeMillis()).values
                .filter { it.totalTimeInForeground >= 60000 }.sortedByDescending { it.totalTimeInForeground }.take(15).forEach {
                    val n = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it.packageName, 0)).toString() } catch (e: Exception) { it.packageName }
                    l.add(tv("$n – ${it.totalTimeInForeground / 60000} min"))
                }
        }
        page(*l.toTypedArray())
    }
}

class MusicActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 60, 0, 0) }
        val row = LinearLayout(this)
        listOf("Spotify" to "com.spotify.music", "YouTube Music" to "com.google.android.apps.youtube.music", "Apple Music" to "com.apple.android.music",
            "Deezer" to "deezer.android.app", "Audiomack" to "com.audiomack", "Boomplay" to "com.afmobi.boomplayer").forEach { (n, p) ->
            packageManager.getLaunchIntentForPackage(p)?.let { i -> row.addView(btn(n) { startActivity(i) }) }
        }
        root.addView(HorizontalScrollView(this).apply { addView(row) })
        root.addView(WebView(this).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; webViewClient = WebViewClient(); loadUrl("https://music.youtube.com") }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}
