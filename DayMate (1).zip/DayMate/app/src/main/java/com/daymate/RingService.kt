package com.daymate
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.net.Uri
import android.os.IBinder

class RingService : Service() {
    private var ring: Ringtone? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") { stopRing(); return START_NOT_STICKY }
        val id = i?.getIntExtra("id", -1) ?: -1
        val a = Store.get(this, id) ?: return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ring", "Alarms", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        if (a.dnd != 0 && nm.isNotificationPolicyAccessGranted)
            nm.setInterruptionFilter(if (a.dnd == 1) NotificationManager.INTERRUPTION_FILTER_ALARMS else NotificationManager.INTERRUPTION_FILTER_ALL)
        val full = PendingIntent.getActivity(this, id, Intent(this, RingActivity::class.java).putExtra("id", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "ring").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(a.label.ifEmpty { "DayMate" }).setContentText(if (a.call) "Time to call ${a.name}" else "Alarm")
            .setCategory(Notification.CATEGORY_ALARM).setFullScreenIntent(full, true).setContentIntent(full).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        val uri = if (a.tone.isEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) else Uri.parse(a.tone)
        ring = RingtoneManager.getRingtone(this, uri)?.apply {
            audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            isLooping = true; play()
        }
        return START_NOT_STICKY
    }
    private fun stopRing() { ring?.stop(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
    override fun onDestroy() { ring?.stop() }
}
