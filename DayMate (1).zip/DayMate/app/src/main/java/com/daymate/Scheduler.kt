package com.daymate
import android.app.*
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    fun next(a: Alarm): Long {
        val t = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (t.timeInMillis <= System.currentTimeMillis()) t.add(Calendar.DAY_OF_YEAR, 1)
        return t.timeInMillis
    }
    private fun pi(c: Context, id: Int, snooze: Boolean) = PendingIntent.getBroadcast(
        c, if (snooze) id + 1_000_000 else id,
        Intent(c, AlarmReceiver::class.java).putExtra("id", id).putExtra("snz", snooze),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    // setAlarmClock = exact, fires through Doze/lock screen, shows the alarm icon in the status bar
    fun set(c: Context, a: Alarm, at: Long = next(a), snooze: Boolean = false) {
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, a.id, snooze))
    }
    fun cancel(c: Context, id: Int) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(pi(c, id, false)); am.cancel(pi(c, id, true))
    }
    fun snooze(c: Context, a: Alarm) = set(c, a, System.currentTimeMillis() + 10 * 60_000L, true)
}
