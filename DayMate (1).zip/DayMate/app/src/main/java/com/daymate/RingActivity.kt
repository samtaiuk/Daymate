package com.daymate
import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class RingActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        getSystemService(KeyguardManager::class.java).requestDismissKeyguard(this, null)
        val a = Store.get(this, intent.getIntExtra("id", -1)) ?: return finish()
        fun stop() = startService(Intent(this, RingService::class.java).setAction("STOP"))
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; textSize = 20f; setOnClickListener { f() } }
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.parseColor("#1B6B2F"))
        }
        v.addView(TextView(this).apply { text = "%02d:%02d".format(a.hour, a.minute); textSize = 64f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        v.addView(TextView(this).apply {
            text = a.label.ifEmpty { "DayMate" } + if (a.call) "\nCall ${a.name}?" else ""
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 0, 0, 48)
        })
        if (a.call) v.addView(btn("📞 Call ${a.name}") {
            stop()
            val ok = checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            startActivity(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.number))))
            finish()
        })
        v.addView(btn("Snooze 10 min") { stop(); Scheduler.snooze(this, a); finish() })
        v.addView(btn("Dismiss") { stop(); finish() })
        setContentView(v)
    }
}
