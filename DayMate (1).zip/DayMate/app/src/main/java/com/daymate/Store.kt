package com.daymate
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** dnd: 0 = leave as is, 1 = turn DND on (alarms only), 2 = turn DND off */
data class Alarm(val id: Int, var hour: Int, var minute: Int, var label: String, var daily: Boolean,
                 var call: Boolean, var name: String, var number: String, var tone: String,
                 var dnd: Int, var on: Boolean = true)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("dm", 0)
    fun all(c: Context): MutableList<Alarm> {
        val a = JSONArray(p(c).getString("alarms", "[]"))
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Alarm(o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getString("l"), o.getBoolean("d"), o.getBoolean("c"),
                o.getString("n"), o.getString("p"), o.getString("t"), o.getInt("dnd"), o.getBoolean("on"))
        }
    }
    fun save(c: Context, l: List<Alarm>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("h", it.hour).put("m", it.minute).put("l", it.label)
            .put("d", it.daily).put("c", it.call).put("n", it.name).put("p", it.number).put("t", it.tone)
            .put("dnd", it.dnd).put("on", it.on)) }
        p(c).edit().putString("alarms", a.toString()).apply()
    }
    fun get(c: Context, id: Int) = all(c).firstOrNull { it.id == id }
    fun update(c: Context, a: Alarm) = save(c, all(c).map { if (it.id == a.id) a else it })
}
