package com.daymate
import android.app.*
import android.content.*
import android.os.Bundle
import android.view.View
import java.util.Calendar

class WaterReceiver : BroadcastReceiver() {
    companion object {
        private fun pi(c: Context) = PendingIntent.getBroadcast(c, 77, Intent(c, WaterReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        fun schedule(c: Context, m: Int) {
            c.getSharedPreferences("dm", 0).edit().putInt("water", m).apply()
            c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + m * 60000L, pi(c))
        }
        fun stop(c: Context) {
            c.getSharedPreferences("dm", 0).edit().putInt("water", 0).apply()
            c.getSystemService(AlarmManager::class.java).cancel(pi(c))
        }
    }
    override fun onReceive(c: Context, i: Intent) {
        val m = c.getSharedPreferences("dm", 0).getInt("water", 0)
        if (m == 0) return
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) in 7..21) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("water", "Water", NotificationManager.IMPORTANCE_DEFAULT))
            nm.notify(2, Notification.Builder(c, "water").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("💧 Time to drink water").setAutoCancel(true).build())
        }
        schedule(c, m)
    }
}

class WaterActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val cur = getSharedPreferences("dm", 0).getInt("water", 0)
        val s = tv(if (cur > 0) "Reminding every $cur min (7am–10pm)" else "Water reminders are off")
        val vs = mutableListOf<View>(tv("💧 Drink water", 26f), s)
        listOf(30, 60, 90, 120).forEach { m -> vs.add(btn("Every $m minutes") { WaterReceiver.schedule(this, m); s.text = "Reminding every $m min (7am–10pm)" }) }
        vs.add(btn("Turn off") { WaterReceiver.stop(this); s.text = "Water reminders are off" })
        page(*vs.toTypedArray())
    }
}
