package com.daymate
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.os.Process
import android.widget.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

const val TASK = 0x800000
fun Context.ex(id: Int) = JSONObject(getSharedPreferences("dm", 0).getString("tk$id", "{}")!!)
fun Context.setEx(id: Int, o: JSONObject) = getSharedPreferences("dm", 0).edit().putString("tk$id", o.toString()).apply()
fun Context.hasUsage() = getSystemService(AppOpsManager::class.java)
    .checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
fun today(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
fun Activity.tv(s: String, sz: Float = 16f) = TextView(this).apply { text = s; textSize = sz; setPadding(0, 12, 0, 12) }
fun Activity.btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
fun Activity.page(vararg v: android.view.View) {
    val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
    v.forEach { l.addView(it) }
    setContentView(ScrollView(this).apply { addView(l) })
}
