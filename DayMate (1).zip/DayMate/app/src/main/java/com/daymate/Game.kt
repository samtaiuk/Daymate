package com.daymate
import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.core.content.ContextCompat

class GameService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var cur: String? = null
    private var since = System.currentTimeMillis() - 10 * 60000
    private val tick = object : Runnable { override fun run() { check(); h.postDelayed(this, 5000) } }
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("game", "Game limit", NotificationManager.IMPORTANCE_LOW))
        startForeground(3, Notification.Builder(this, "game").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Game limit active").build(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        h.removeCallbacks(tick); h.post(tick); return START_STICKY
    }
    override fun onDestroy() { h.removeCallbacks(tick) }
    @Suppress("DEPRECATION")
    private fun isGame(p: String) = try {
        val ai = packageManager.getApplicationInfo(p, 0)
        ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    } catch (e: Exception) { false }

    private fun check() {
        val sp = getSharedPreferences("dm", 0); val limit = sp.getInt("glimit", 0)
        if (limit == 0 || !hasUsage()) return
        val now = System.currentTimeMillis()
        val ev = getSystemService(UsageStatsManager::class.java).queryEvents(since, now); since = now
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> cur = e.packageName
                UsageEvents.Event.ACTIVITY_PAUSED -> if (cur == e.packageName) cur = null
            }
        }
        val c = cur ?: return
        if (!isGame(c)) return
        val k = "gplay" + today(); val t = sp.getLong(k, 0) + 5000; sp.edit().putLong(k, t).apply()
        if (t >= limit * 60000L) startActivity(Intent(this, LimitActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }
}

class LimitActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48); setBackgroundColor(Color.parseColor("#B71C1C")) }
        v.addView(TextView(this).apply { text = "🎮 Game time is up"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        v.addView(TextView(this).apply { text = "Your daily game limit is reached.\nTake a break!"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 24, 0, 48) })
        v.addView(btn("Close game") { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); finish() })
        setContentView(v)
    }
}

class GameActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("dm", 0)
        val s = tv("")
        fun show() { val l = p.getInt("glimit", 0)
            s.text = (if (l > 0) "Limit: $l min/day · active" else "Game limit is off") + "\nPlayed today: ${p.getLong("gplay" + today(), 0) / 60000} min" }
        show()
        val vs = mutableListOf<android.view.View>(tv("🎮 Game limit", 26f), s)
        listOf(30, 60, 90, 120).forEach { m -> vs.add(btn("Limit $m min per day") {
            p.edit().putInt("glimit", m).apply(); ContextCompat.startForegroundService(this, Intent(this, GameService::class.java)); show() }) }
        vs.add(btn("Turn off") { p.edit().putInt("glimit", 0).apply(); stopService(Intent(this, GameService::class.java)); show() })
        vs.add(tv("Step 1 and 2 are required:"))
        vs.add(btn("1. Allow usage access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        vs.add(btn("2. Allow display over other apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        page(*vs.toTypedArray())
    }
}
