package com.daymate
import android.app.Activity
import android.content.Intent
import android.widget.*

class AlarmsActivity : Activity() {
    private val mode get() = intent.getStringExtra("mode") ?: "pair"
    override fun onResume() { super.onResume(); render() }

    private fun render() {
        val me = this
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        root.addView(tv(mapOf("pair" to "Sleep & wake-up", "call" to "Routine calls", "task" to "Daily itinerary")[mode]!!, 26f))
        val all = Store.all(this)
        val list = when (mode) {
            "call" -> all.filter { it.call }
            "task" -> all.filter { it.id >= TASK }.sortedBy { it.hour * 60 + it.minute }
            else -> all.filter { !it.call && it.id < TASK && it.id % 2 == 0 }
        }
        list.forEach { a ->
            val w = if (mode == "pair") all.firstOrNull { it.id == a.id + 1 } else null
            val txt = when (mode) {
                "pair" -> "😴 %02d:%02d → 🌅 %s\n%s · DND automatic".format(a.hour, a.minute, w?.let { "%02d:%02d".format(it.hour, it.minute) } ?: "--", if (a.daily) "Every day" else "Once")
                "task" -> { val e = ex(a.id)
                    "%s %02d:%02d  %s%s\nEnd: %s  %s".format(listOf("⏳", "✅", "⏭️")[e.optInt("s")], a.hour, a.minute, a.label, if (a.daily) " 🔁" else "", e.optString("e").ifEmpty { "--" }, e.optString("r")) }
                else -> "%02d:%02d  %s\n%s · %s".format(a.hour, a.minute, a.label, if (a.daily) "Every day" else "Once", a.name)
            }
            val row = LinearLayout(this).apply { setPadding(0, 24, 0, 24) }
            row.addView(TextView(this).apply {
                text = txt; textSize = 18f
                setOnClickListener { startActivity(Intent(me, EditActivity::class.java).putExtra("id", a.id).putExtra("mode", mode)) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Switch(this).apply {
                isChecked = a.on
                setOnCheckedChangeListener { _, on ->
                    listOfNotNull(a, w).forEach { x -> x.on = on; Store.update(me, x); if (on) Scheduler.set(me, x) else Scheduler.cancel(me, x.id) }
                }
            })
            root.addView(row)
        }
        root.addView(btn("+ New") { startActivity(Intent(me, EditActivity::class.java).putExtra("mode", mode)) })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
